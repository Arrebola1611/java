
package evaluacion;


public class Evaluacion {

    
    public static void main(String[] args) {
       
    incentivo calificacion = new incentivo();    
   incentivo obsequio = new incentivo(); 
   
    obsequio.obtenerNota("turrones");
   
    calificacion.obtenerRegalo(10);
    calificacion.ordenar();
    
    
     

    
    
    
    
    
    
    
    }
    }




























    }
    
}
