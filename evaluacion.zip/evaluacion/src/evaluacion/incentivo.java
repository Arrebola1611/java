
package evaluacion;


public class incentivo {
   
   String[] regalo = new String[]{"jamon","bombones","postal","turrones","cava","ibericos"};
   int  [] nota  = new int []{10,8,5,7,6,9} ;
   int cont;
   int cont2;
   int aux;
   int result;
   String result2;
    void obtenerNota(String x ){
         //System.out.println("La x vale " + x );
         for (cont=0;cont<6;cont++){
            //System.out.println(regalo[cont]);
             if (regalo[cont] == x){
                 aux=cont;
                 result=nota[aux];
                 System.out.println("Si regalas " + x  + " seguramente tengas un " + result);
             }
        }
         
         for (cont2=0;cont2<6;cont2++){
            //System.out.println(nota[cont2]);
        }
        
         
         
         
        
    }
     
    void obtenerRegalo(int y ){
         //System.out.println("La x vale " + x );
         for (cont=0;cont<6;cont++){
            //System.out.println(regalo[cont]);
            
        }
         
         for (cont2=0;cont2<6;cont2++){
            //System.out.println(nota[cont2]);
              if (nota[cont2] == y){
                 aux=cont2;
                 result2=regalo[aux];
                 System.out.println("Si quieres un  " + y  + " convendria comprar unos " + result2);
             }
        }
        
         
         
         
        
    }
    
     void ordenar(){
    int i;
    int j;
    int x=0;
       for (i=0;i<=5;i++)
       {
           //System.out.println(i);
          // System.out.println("la j " + j);
           
           for (j=i+1;j<6;j++){
           if (nota[i]>nota[j])
           {
              x=nota[i];
              nota[i]=nota[j];
              nota[j]=x;
           }
           }
            
          
       }
         System.out.println("El vector nota ordenado es:" );
     for(i=5;i>0;i--)
	{
           System.out.print( nota[i] + " ");                      
                        
	} 
     System.out.println("\n El vector regalo ordenado es:" );
       for(i=5;i>0;i--)
	{
         System.out.print(regalo[i] + " " );                     
                        
	} 
     }

    }


 
 
    
  